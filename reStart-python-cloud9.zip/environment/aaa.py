#while loop
counter = 0

while counter <= 3:
    print("saya suka belajar ular")
    counter = counter + 4
    
#for loop
myList =["apel", "jeruk", "mangga"]

for data in myList:
    print(data)
    
for loop in range(2, 12, 2):
    print(loop)