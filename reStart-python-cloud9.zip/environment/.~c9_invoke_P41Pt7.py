userReply = input("paket? (Enter iya or ya) ")

if userReply == "ya":
    print("kita bukan paket yahaha")