var1 = 2 
def penjumlahan():
    a = 5
    b = 7
    hasil = a + b
    return hasil

print(penjumlahan())

def pengurangan(x, y):
    print(x)
    print(y)
    hasil = x - y
    return hasil

print (pengurangan(5, 3))