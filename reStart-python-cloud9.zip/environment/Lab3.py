# Latihan 0
# myString = "ini wildan"
# print(myString)
# print(type(myString))

# Latihan 1
# firstString = "aku"
# secondString = "wildan"
# thirdString = "adila"
# hasil = firstString + " " + secondString + " " + thirdString
# print(hasil)

# Latihan 3
nama = input("man rabbuka? ")
print(nama)

# Latihan 4
nomor = input("berapa banyak dosa kamu? ")
# conversi_nomor = int(nomor)
print(nomor)
print(type(nomor))

print("nama kamu? {} dan dosa kamu berapa? {}", format(nama, nomor))